function mulaiGame() {
    window.location.href = "game.html";
}

function pembuatGame() {
    window.open("https://www.youtube.com/@ArselAdy283");
}

function keluarGame() {
    alert('Terimaksih sudah bermain');
}
